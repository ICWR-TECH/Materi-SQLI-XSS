<?php
$koneksi=mysqli_connect("localhost", "root", "jancok123", "sql_xss");
if(!$koneksi) {
    echo "Database Error";
    exit();
}
