<?php
include("conf.php");
session_start();
?>
<?php
if($_GET['logout'] == "true") {
    session_destroy();
    echo "<script>window.location = '?login=true';</script>";
    exit;
}
if($_SESSION['login'] == "masuk") {
    echo "<title>Admin Page</title>\nYou Logged With User $_SESSION[user]";
    echo "<br><a href='?logout=true'>Logout</a>";
    exit;
}
?>
<title>Admin Page Website</title>
<style>
    html {
        background: black;
        color: white;
    }
    .kotak {
        padding: 20px;
        border-radius: 20px;
        background: white;
        color: black;
        width: 30%;
    }
    input {
        border-radius: 20px;
        background: black;
        color: white;
    }
</style>
<center>
    <h1>Admin Page Website</h1>
    <div class="kotak">
        <form enctype="multipart/form-data" method="post">
            Username : <input type="text" name="user">
            <br><br>
            Password : <input type="password" name="pass">
            <br><br>
            <input type="submit" name="login" value="Login">
<?php
if($_POST['login']) {
    $user=mysqli_real_escape_string($koneksi, $_POST['user']);
    $pass=mysqli_real_escape_string($koneksi, $_POST['pass']);
    $cek=mysqli_query($koneksi, "SELECT * FROM admin_user WHERE username='$user' AND password='$pass'");
    if(mysqli_num_rows($cek) > 0) {
        $_SESSION['user'] = $_POST['user'];
        $_SESSION['login'] = "masuk";
        echo "<script>window.location = 'index.php';</script>";
        exit;
    }
}
?>
        </form>
    </div>
    <br><br>
    Copyleft &copy;2019 - ICWR
</center>
